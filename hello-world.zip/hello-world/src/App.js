
import './App.css'
import Home from  './components/Home'
import React from "react"

const App = () => <Home/>

export default App
